<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>CRUD DE USUARIOS</title>
    <link href="web/default.css" rel="stylesheet" type="text/css" />
    <script type="text/javascript" src="web/js/funciones.js"></script>
    <style>
        * {
            color: #0000cc;
        }
    </style>
</head>
<body>
<div id="container" >
    <div id="header">
        <h1>GESTIÓN DE USUARIOS versión 1.1 + BD</h1>
    </div>
    <form method="get">
        <label>INTRODUZCA EL PIN DE ACCESO<input type="text" name="pin"></label>
    </form>
</div>
</body>
